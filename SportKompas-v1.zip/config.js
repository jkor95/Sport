// Only public connection details belong in this file. Never put a service_role,
// secret key, personal password, or OpenAI key here or anywhere on GitHub.
globalThis.SPORT_CONFIG = {
  supabaseUrl: '',
  supabasePublishableKey: '',
  appName: 'SportKompas',
  enableAI: false,
  // Pin the SDK. The demo and planner do not need this external library.
  sdkUrl: 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.57.4/dist/umd/supabase.js'
};
